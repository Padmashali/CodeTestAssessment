//
//  ContentView.swift
//  CodeTestAssessment
//
//  Created by PAVAN PADMASHALI on 26/04/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        PostListView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
