//
//  PostViewModel.swift
//  CodeTestAssessment
//
//  Created by PAVAN PADMASHALI on 26/04/24.
//

import Foundation
import Combine

class PostViewModel: ObservableObject {
    @Published var posts: [Post] = []
    private var cancellables = Set<AnyCancellable>()
    private let apiService = APIService()
    private var currentPage = 1
    private let itemsPerPage = 20

    init() {
        fetchPosts()
    }

    func fetchPosts() {
        let url = apiService.baseURL.appendingQueryParameters(["_page": "\(currentPage)", "_limit": "\(itemsPerPage)"])

        URLSession.shared.dataTaskPublisher(for: url)
            .map { $0.data }
            .decode(type: [Post].self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completion in
                switch completion {
                case .failure(let error):
                    print("Error fetching posts: \(error.localizedDescription)")
                case .finished:
                    break
                }
            }, receiveValue: { [weak self] newPosts in
                self?.posts.append(contentsOf: newPosts)
                self?.currentPage += 1
            })
            .store(in: &cancellables)
    }

    func performHeavyComputation(for post: Post) -> String {
        let startTime = CFAbsoluteTimeGetCurrent()

        // Perform heavy computation here
        // ...

        let endTime = CFAbsoluteTimeGetCurrent()
        let timeTaken = endTime - startTime
        print("Time taken for heavy computation: \(timeTaken) seconds")

        return post.body
    }
}
