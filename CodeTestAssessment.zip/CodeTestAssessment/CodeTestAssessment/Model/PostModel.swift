//
//  PostModel.swift
//  CodeTestAssessment
//
//  Created by PAVAN PADMASHALI on 26/04/24.
//

import Foundation

struct Post: Codable, Identifiable {
    let id: Int
    let title: String
    let body: String
}
