//
//  PostDetailView.swift
//  CodeTestAssessment
//
//  Created by PAVAN PADMASHALI on 26/04/24.
//

import SwiftUI

struct PostDetailView: View {
    let post: Post
    @ObservedObject private var viewModel: PostViewModel

    init(post: Post, viewModel: PostViewModel) {
        self.post = post
        self.viewModel = viewModel
    }

    var body: some View {
        VStack {
            Text(post.title)
                .font(.headline)

            Divider()

            Text(viewModel.performHeavyComputation(for: post))
                .font(.body)
        }
        .padding()
        .navigationBarTitle("Post Details")
    }
}
