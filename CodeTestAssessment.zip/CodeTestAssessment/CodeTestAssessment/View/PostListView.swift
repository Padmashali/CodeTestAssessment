//
//  PostListView.swift
//  CodeTestAssessment
//
//  Created by PAVAN PADMASHALI on 26/04/24.
//

import SwiftUI

struct PostListView: View {
    @ObservedObject private var viewModel = PostViewModel()

    var body: some View {
        NavigationView {
            List(viewModel.posts) { post in
                NavigationLink(destination: PostDetailView(post: post, viewModel: viewModel)) {
                    VStack(alignment: .leading) {
                        Text("\(post.id)")
                        Text(post.title)
                    }
                }
            }
            .navigationBarTitle("Posts")
        }
    }
}
