//
//  PostAPIServices.swift
//  CodeTestAssessment
//
//  Created by PAVAN PADMASHALI on 26/04/24.
//

import Foundation

class APIService {
    let baseURL = URL(string: "https://jsonplaceholder.typicode.com/posts")!
}

extension URL {
    func appendingQueryParameters(_ parameters: [String: String]) -> URL {
        var urlComponents = URLComponents(url: self, resolvingAgainstBaseURL: true)
        var queryItems: [URLQueryItem] = []

        for (key, value) in parameters {
            queryItems.append(URLQueryItem(name: key, value: value))
        }

        urlComponents?.queryItems = queryItems

        return urlComponents?.url ?? self
    }
}
